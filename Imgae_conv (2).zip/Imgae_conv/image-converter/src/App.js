 // src/App.js
import React from 'react';
import ImageConverter from './ImageConverter';

const App = () => {
  return (
    <div className="App">
      <h1>Image Converter</h1>
      <ImageConverter />
    </div>
  );
};

export default App;
